1)
a. Ryan Jewik
b. 2404275
c. jewik@chapman.edu
d. CPSC 350-01
e. Programming Assignment 5: THE GOAT
2)
a.DblList.h
b.Faculty.h
c.Faculty.cpp
d.ListNode.h
e.Main.cpp
f.Person.h
g.ScapegoatST.h
h.Student.cpp
i.Student.h
j.TreeNode.h
3)n/a
4)worked with Tyler Edwards
5)g++ *.cpp -o run
./run