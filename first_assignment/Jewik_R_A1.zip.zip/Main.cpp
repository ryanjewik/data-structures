#include "FileProcessor.h"

int main(){
    FileProcessor fileprocessor;
    fileprocessor.processFile("test.txt", "blank.html");
    return 0;
};