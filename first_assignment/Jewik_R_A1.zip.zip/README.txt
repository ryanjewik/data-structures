Ryan Jewik
2404275 

Model.cpp
Model.h
Translator.cpp
Translator.h
FileProcessor.cpp
FileProcessor.h
Main.cpp
test.txt
blank.html

Collaborators:
Szymon Kozlowski
Tyler Edwards
Maverick Wadman
Kevin Huang
Elizabeth Stevens
References:
cplusplus.com isVowel, isalpha, reading/writing from files

g++ -o test *.cpp
./test