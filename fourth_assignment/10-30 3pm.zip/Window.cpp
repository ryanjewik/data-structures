/// @file Window.cpp
/// @brief Allows for the creation of a Window object.
/// @author Tyler Edwards - tyedwards@chapman.edu

using namespace std;
#include "Window.h"

Window::Window()
{
  cout << "window created" << endl;
  m_idleTime = 0;
  m_longestIdleTime = 0;

  m_isOpen = true;
  m_overFive = false;
}

Window::~Window(){
  std::cout<<"window destructed" << std::endl;
}

int Window::print()
{
  return m_idleTime;
}

void Window::addCustomer(Customer c)
{
  cout << "adding customer" << endl;
  m_customer.addBack(c);
  //cout << m_customer->getTimeF() << endl;
}

bool Window::windowOpen(){// change me
  if (m_customer.isEmpty() == true){
    cout << "window empty" << endl;
    m_isOpen = true;
    return true;
  }
  else{
    cout << "window occupied" << endl;
    m_isOpen = false;
    return false;
  }
}

Customer Window::getCustomer(){//change me
  return m_customer.get(0);
}