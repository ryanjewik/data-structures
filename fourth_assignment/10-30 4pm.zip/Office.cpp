/// @file Office.cpp
/// @brief Allows for the creation of a Office object.
/// @author Tyler Edwards - tyedwards@chapman.edu

using namespace std;

#include "Office.h"

Office::Office(){}

Office::~Office(){}

Office::Office(int n)
{
  m_nWindows = n;
  m_longestIdleTime = 0;
  m_windowsFive = 0;
  m_meanIdleTime = 0;

  m_officeLine = new ListQueue<Customer>;

  for(int i = 0; i < m_nWindows; ++i)
  {
    Window w;
    m_windows.addBack(w);
  }

  for(int i = 0; i < m_nWindows; ++i)
  {
    Window test = m_windows.get(i);
    //cout << test.print() << endl;
  }
}

void Office::windowCustomer()
{
  for (int i = 0; i < m_nWindows; ++i){
    if (m_windows.get(i).windowOpen() == true){
        cout << "window: " << i << " is empty so we will add here." << endl;
        cout << "office line size " << m_officeLine->size() << endl;
        //Customer test = m_officeLine->remove();
        cout << "empty window customer time 1: " << m_windows.get(i).m_customer[0].getTimeOne() << endl;
        Customer tempC = m_officeLine->remove();
        cout << endl;
        cout << "temp customer attributes" << endl;
        cout << tempC.getTimeOne() << endl;
        cout << endl;
        m_windows.get(i).addCustomer(tempC);
        cout << "office line size " << m_officeLine->size() << endl;
        cout << "is window open? " << m_windows.get(i).windowOpen() << endl;
        cout << "added customer time 1: " << m_windows.get(i).m_customer[0].getTimeOne() << endl;
        break;
    }
  }
  
}

bool Office::totallyEmpty(){
  bool windowsEmptyVar = true;
  for(int i = 0; i < m_nWindows; ++i)
  {
    cout <<"checking window: " << i << endl;
    if (m_windows.get(i).windowOpen() == false){
      windowsEmptyVar = false;
      
    }
  }
  if (m_officeLine->isEmpty() == true && windowsEmptyVar == true){
    return true;
  }
  else{
    return false;
  }
}

bool Office::windowsEmpty(){
  for(int i = 0; i < m_nWindows; ++i)
  {
    cout << "Check window: " << i << endl;
    if (m_windows.get(i).windowOpen() == false){
      return false;
      exit;
    }
  }
  return true;
}