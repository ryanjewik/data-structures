/// @file ServiceCenter.h
/// @brief Allows for the creation of a Service Center object.
/// @author Tyler Edwards - tyedwards@chapman.edu

#include "ServiceCenter.h"

using namespace std;

ServiceCenter::ServiceCenter(){}

ServiceCenter::~ServiceCenter(){}

ServiceCenter::ServiceCenter(std::string file)
{
  m_file = file;
  ifstream inFile;
  inFile.open(m_file, ios::in);
  m_secTime = 0;
  inFile >> m_rWindow;
  inFile >> m_cWindow;
  inFile >> m_fWindow;

  Office Registrar(m_rWindow);
  Office Cashier(m_cWindow);
  Office financialAid(m_fWindow);
  DblList<Office> Offices;
  Offices.addBack(Registrar);
  Offices.addBack(Cashier);
  Offices.addBack(financialAid);



    if (inFile.is_open()){
      //while(!inFile.eof()){
      inFile >> m_time;
      inFile >> m_nCustomers;
        for(int i = 0; i < m_nCustomers; ++i) // populates the queues and reads the first hour
        {
          m_officeTimes = new int[3];
          m_officeTypes = new char[3];
          m_officeOrder = new char[3];

          for(int k = 0; k < 6; ++k)
          {
            if(k <= 2)
            {
              inFile >> m_officeTimes[k];
            }

            else
            {
              inFile >> m_officeTypes[k - 3];
              m_officeOrder[k - 3] = m_officeTypes[k - 3] ;
            }
          }


          Customer c(m_officeTimes[0], m_officeTimes[1], m_officeTimes[2], m_officeOrder[0], m_officeOrder[1], m_officeOrder[2]);

          switch(c.getOfficeOne())
          {
              case 'C':
                cout << "It's a C" << endl;
                Cashier.m_officeLine->add(c);
                Cashier.windowCustomer();
                break;

              case 'F':
                cout << "It's a F" << endl;
                financialAid.m_officeLine->add(c);
                financialAid.windowCustomer();
                break;

              case 'R':
                cout << "It's a R" << endl;
                Registrar.m_officeLine->add(c);
                Registrar.windowCustomer();
                break;

              default:
                cout << "invalid char" << endl;
                break;
          }
          }//initial set of students at opening

          inFile >> m_time;
          inFile >> m_nCustomers;
          /*
          while(!inFile.eof() && (financialAid.totallyEmpty() != true && 
          (Registrar.totallyEmpty() != true && Cashier.totallyEmpty() != true))){//time only stops when it's the end of the file and the queues are empty
            
            m_secTime +=1; //time has started
            
              for (int c = 0; c < Cashier.m_windows.size(); ++c){//Cashier check windows and see who is done
                if (Cashier.m_windows.get(c).getCustomer()->getDepartureTime() == m_secTime){
                  switch(Cashier.m_windows.get(c).getCustomer()->getOfficesVisited()){
                    case 0:
                    //send to first office
                    break;
                    case 1:
                    //send to second office
                    break;
                    case 2:
                    //send to third office
                    break;
                  }//switch statement to send to which office
                }//if statement if the departure time has been met
              }//loops for each window to check

              for (int c = 0; c < Cashier.m_windows.size(); ++c){//financial aid check windows and see who is done
                if (financialAid.m_windows.get(c).getCustomer()->getDepartureTime() == m_secTime){
                  switch(financialAid.m_windows.get(c).getCustomer()->getOfficesVisited()){
                    case 0:
                    //send to first office
                    break;
                    case 1:
                    //send to second office
                    break;
                    case 2:
                    //send to third office
                    break;
                  }//switch statement to send to which office
                }//if statement if the departure time has been met
              }//loops for each window to check

              for (int c = 0; c < Cashier.m_windows.size(); ++c){//registrar check windows and see who is done
                if (Registrar.m_windows.get(c).getCustomer()->getDepartureTime() == m_secTime){
                  switch(Registrar.m_windows.get(c).getCustomer()->getOfficesVisited()){
                    case 0:
                    //send to first office
                    //then move the queue along
                    break;
                    case 1:
                    //send to second office
                    //then move the queue along
                    break;
                    case 2:
                    //send to third office
                    //then move the queue along
                    break;
                  }//switch statement to send to which office
                }//if statement if the departure time has been met
              }//loops for each window to check
            

            if (m_secTime == m_time * 60){ // the next hour that customers arrive, adds all of them to the queues

              for(int i = 0; i < m_nCustomers; ++i)
              { // creates each customer and adds them to their queue
                m_officeTimes = new int[3];
                m_officeTypes = new char[3];
                m_officeOrder = new char[3];

                for(int k = 0; k < 6; ++k) //reads each attribute and adds them to an array
                {
                  if(k <= 2)
                  {
                    inFile >> m_officeTimes[k];
                  }

                  else
                  {
                    inFile >> m_officeTypes[k - 3];
                    m_officeOrder[k - 3] = m_officeTypes[k - 3] ;
                  }
                }



                Customer c(m_officeTimes[0], m_officeTimes[1], m_officeTimes[2], m_officeOrder[0], m_officeOrder[1], m_officeOrder[2]); // creates customer object

                switch(c.getOfficeOne())//reads each character and finds which office to put them in first
                {
                    case 'C':
                      cout << "It's a C" << endl;
                      Cashier.m_officeLine->add(c);
                      Cashier.windowCustomer();
                      break;

                    case 'F':
                      cout << "It's a F" << endl;
                      financialAid.m_officeLine->add(c);
                      financialAid.windowCustomer();
                      break;

                    case 'R':
                      cout << "It's a R" << endl;
                      Registrar.m_officeLine->add(c);
                      Registrar.windowCustomer();
                      break;

                    default:
                      cout << "invalid char" << endl;
                      break;
                } // first office bracket
                }//creates each customer object
              }//adds new set of customers bracket
              inFile >> m_time;
              inFile >> m_nCustomers;
            }//time bracket */
          // std::cout << Cashier.m_officeLine->size() << std::endl;
          // std::cout << financialAid.m_officeLine->size() << std::endl;
          // std::cout << Registrar.m_officeLine->size() << std::endl;
          //cout << c.getOfficeOne() << " " << c.getOfficeTwo() << " " << c.getOfficeThree() << endl;
          }//initial assignment of m_time and m_nCustomers bracket
        //}//if file is open
      inFile.close();
      cout << Cashier.m_windows.size() << endl;
      cout << financialAid.m_windows.size() <<endl;
      cout << Registrar.m_windows.size() <<endl;
      
      cout << Cashier.totallyEmpty() << endl;
      cout << financialAid.totallyEmpty() << endl;
      cout << Registrar.totallyEmpty() << endl;
    }//constructor bracket


void ServiceCenter::newWave(){

}