/// @file Window.cpp
/// @brief Allows for the creation of a Window object.
/// @author Tyler Edwards - tyedwards@chapman.edu

using namespace std;
#include "Window.h"

Window::Window()
{
  cout << "window created" << endl;
  m_idleTime = 0;
  m_longestIdleTime = 0;

  m_isOpen = true;
  m_overFive = false;
  Customer m_customer [1];
  Customer c;
  m_customer[0] = c;
}

Window::~Window(){
  std::cout<<"window destructed" << std::endl;
}

int Window::print()
{
  return m_idleTime;
}

void Window::addCustomer(Customer c)
{
  cout << "adding customer" << endl;
  cout << "the customer being added's time one: "<< c.getTimeOne() << endl;
  m_customer[0] = c;
  cout << m_customer[0].getTimeOne() << endl;
}

bool Window::windowOpen(){// change me
  if (m_customer[0].getTimeOne() == -1){
    cout << "window empty" << endl;
    m_isOpen = true;
    return true;
  }
  else{
    cout << "window occupied" << endl;
    m_isOpen = false;
    return false;
  }
}

Customer Window::getCustomer(){//change me
  return m_customer[0];
}