/// @file Window.h
/// @brief Allows for the creation of a Window object. (header)
/// @author Tyler Edwards - tyedwards@chapman.edu

#ifndef WINDOW_H
#define WINDOW_H
#include <iostream>

#include "DblList.h"
#include "Customer.h"

class Window
{
  public:
    Window();
    virtual ~Window();
    bool windowOpen();

    int m_idleTime;
    int m_longestIdleTime;

    bool m_isOpen;
    bool m_overFive;

    int print();

    //Customer* m_customer;
    void addCustomer(Customer c);
    Customer m_customer [1];
    Customer getCustomer();

  private:
};

#endif
