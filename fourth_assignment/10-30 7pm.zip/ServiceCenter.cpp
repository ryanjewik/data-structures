/// @file ServiceCenter.h
/// @brief Allows for the creation of a Service Center object.
/// @author Tyler Edwards - tyedwards@chapman.edu

#include "ServiceCenter.h"

using namespace std;

ServiceCenter::ServiceCenter(){}

ServiceCenter::~ServiceCenter(){}

ServiceCenter::ServiceCenter(std::string file)
{
  m_file = file;
  ifstream inFile;
  inFile.open(m_file, ios::in);
  m_secTime = 0;
  inFile >> m_rWindow; // 2
  inFile >> m_cWindow; // 3
  inFile >> m_fWindow; // 1

  Office Registrar(m_rWindow);
  Office Cashier(m_cWindow);
  Office financialAid(m_fWindow);
  DblList<Office> Offices;
  Offices.addBack(Registrar);
  Offices.addBack(Cashier);
  Offices.addBack(financialAid);


    if (inFile.is_open()){
      //while(!inFile.eof()){
      inFile >> m_time;
      inFile >> m_nCustomers;
        for(int i = 0; i < m_nCustomers; ++i) // populates the queues and reads the first hour
        {
          m_officeTimes = new int[3];
          m_officeTypes = new char[3];
          m_officeOrder = new char[3];

          for(int k = 0; k < 6; ++k)
          {
            if(k <= 2)
            {
              inFile >> m_officeTimes[k];
            }

            else
            {
              inFile >> m_officeTypes[k - 3];
              m_officeOrder[k - 3] = m_officeTypes[k - 3] ;
            }
          }


          Customer c(m_officeTimes[0], m_officeTimes[1], m_officeTimes[2], m_officeOrder[0], m_officeOrder[1], m_officeOrder[2]);

          switch(c.getOfficeOne())
          {
              case 'C':
                cout << "It's a C" << endl;
                Cashier.m_officeLine->add(c);
                Cashier.windowCustomer(0);
                break;

              case 'F':
                cout << "It's a F" << endl;
                financialAid.m_officeLine->add(c);
                financialAid.windowCustomer(0);
                break;

              case 'R':
                cout << "It's a R" << endl;
                Registrar.m_officeLine->add(c);
                Registrar.windowCustomer(0);
                break;

              default:
                cout << "invalid char" << endl;
                break;
          }
          }//initial set of students at opening
              cout << Cashier.totallyEmpty() << endl;
              cout << financialAid.totallyEmpty() << endl;
              cout << Registrar.totallyEmpty() << endl;
          cout << "--------------------------------- initial set of customers added" << endl;
          cout << endl;
          cout << endl;
          inFile >> m_time;
          inFile >> m_nCustomers;
          //cout << "offices visited test: " << Registrar.m_windows.get(0).getCustomer().getOfficesVisited() << endl;
          //cout << Registrar.m_windows.get(0).getCustomer().getDepartureTime() << endl;
          cout << Cashier.totallyEmpty() << endl;
          cout << financialAid.totallyEmpty() << endl;
          cout << Registrar.totallyEmpty() << endl;
          /*!inFile.eof() && */
          cout <<"time has started" << endl;
          while((financialAid.totallyEmpty() != 1) || (Registrar.totallyEmpty() != 1 || Cashier.totallyEmpty() != 1)){//time only stops when it's the end of the file and the queues are empty
            m_secTime +=1; //time has started
            cout << "time: " << m_secTime << endl;
              for (int c = 0; c < Cashier.m_windows.size(); ++c){//Cashier check windows and see who is done
                if (Cashier.m_windows.get(c).windowOpen() != 1){
                if (Cashier.m_windows.get(c).getCustomer().getDepartureTime() == m_secTime){
                  switch(Cashier.m_windows.get(c).getCustomer().getOfficesVisited()){
                    case 3:
                    //send to first office
                    satisfiedCustomers.addBack(Cashier.m_windows.get(c).m_customer->remove());
                    cout << "current time: " << m_secTime << " happy customer" << endl;
                    break;
                    case 1:
                    switch(Cashier.m_windows.get(c).getCustomer().getOfficeTwo())
                    {
                        case 'C':
                          cout << "error, shouldn't be C" << endl;
                          break;

                        case 'F':
                          cout << "It's a F" << endl;
                          financialAid.m_officeLine->add(Cashier.m_windows.get(c).m_customer->remove()); // removes from window then adds to next queue
                          Cashier.windowCustomer(m_secTime); // moves the queue along
                          break;

                        case 'R':
                          cout << "It's a R" << endl;
                          Registrar.m_officeLine->add(Cashier.m_windows.get(c).m_customer->remove()); // removes from window then adds to next queue
                          Cashier.windowCustomer(m_secTime); // moves the queue along
                          break;

                        default:
                          cout << "invalid char" << endl;
                          break;
                    }
                    //send to second office
                    break;
                    case 2:
                    switch(Cashier.m_windows.get(c).getCustomer().getOfficeThree())
                    {
                        case 'C':
                          cout << "error, shouldn't be C" << endl;
                          break;

                        case 'F':
                          cout << "It's a F" << endl;
                          financialAid.m_officeLine->add(Cashier.m_windows.get(c).m_customer->remove()); // removes from window then adds to next queue
                          Cashier.windowCustomer(m_secTime); // moves the queue along
                          break;

                        case 'R':
                          cout << "It's a R" << endl;
                          Registrar.m_officeLine->add(Cashier.m_windows.get(c).m_customer->remove()); // removes from window then adds to next queue
                          Cashier.windowCustomer(m_secTime); // moves the queue along
                          break;

                        default:
                          cout << "invalid char" << endl;
                          break;
                    }
                    //send to third office
                    break;
                  }//switch statement to send to which office
                  }//if statement if the departure time has been met
                }//if the window is occupied
              }//loops for each window to check
              for (int c = 0; c < financialAid.m_windows.size(); ++c){//financial aid check windows and see who is done
                if (financialAid.m_windows.get(c).windowOpen() != 1){
                  
                if (financialAid.m_windows.get(c).getCustomer().getDepartureTime() == m_secTime){
                  switch(financialAid.m_windows.get(c).getCustomer().getOfficesVisited()){
                    case 3:
                    //send to first office
                    satisfiedCustomers.addBack(financialAid.m_windows.get(c).m_customer->remove());
                    cout << "current time: " << m_secTime << " happy customer" << endl;
                    break;
                    case 1:
                    switch(financialAid.m_windows.get(c).getCustomer().getOfficeTwo())
                    {
                        case 'C':
                          cout << "It's a C" << endl;
                          Cashier.m_officeLine->add(financialAid.m_windows.get(c).m_customer->remove()); // removes from window then adds to next queue
                          financialAid.windowCustomer(m_secTime); // moves the queue along
                          break;

                        case 'F':
                          cout << "error, shouldn't be F" << endl;
                          break;

                        case 'R':
                          cout << "It's a R" << endl;
                          Registrar.m_officeLine->add(financialAid.m_windows.get(c).m_customer->remove()); // removes from window then adds to next queue
                          financialAid.windowCustomer(m_secTime); // moves the queue along
                          break;

                        default:
                          cout << "invalid char" << endl;
                          break;
                    }
                    //send to second office
                    break;
                    case 2:
                    switch(financialAid.m_windows.get(c).getCustomer().getOfficeThree())
                    {
                        case 'C':
                          cout << "error, shouldn't be C" << endl;
                          break;

                        case 'F':
                          cout << "It's a F" << endl;
                          financialAid.m_officeLine->add(Cashier.m_windows.get(c).m_customer->remove()); // removes from window then adds to next queue
                          Cashier.windowCustomer(m_secTime); // moves the queue along
                          break;

                        case 'R':
                          cout << "It's a R" << endl;
                          Registrar.m_officeLine->add(Cashier.m_windows.get(c).m_customer->remove()); // removes from window then adds to next queue
                          Cashier.windowCustomer(m_secTime); // moves the queue along
                          break;

                        default:
                          cout << "invalid char" << endl;
                          break;
                    }
                    //send to third office
                    break;
                  }//switch statement to send to which office
                }//if statement if the departure time has been met
                }//is window occupied
                
              }//loops for each window to check
             
              for (int c = 0; c < Registrar.m_windows.size(); ++c){//registrar check windows and see who is done
                if (Registrar.m_windows.get(c).windowOpen() != 1){
                  if (Registrar.m_windows.get(c).getCustomer().getDepartureTime() == m_secTime){
                  switch(Registrar.m_windows.get(c).getCustomer().getOfficesVisited()){
                    case 3:
                    //send to first office
                    satisfiedCustomers.addBack(Registrar.m_windows.get(c).m_customer->remove());
                    cout << "current time: " << m_secTime << " happy customer" << endl;
                    break;
                    case 1:
                    switch(Registrar.m_windows.get(c).getCustomer().getOfficeTwo())
                    {
                        case 'C':
                          cout << "It's a C" << endl;
                          cout << Registrar.m_windows.get(c).m_customer->remove().getTimeOne() << endl;
                          Cashier.m_officeLine->add(Registrar.m_windows.get(c).m_customer->remove()); // removes from window then adds to next queue
                          Registrar.windowCustomer(m_secTime); // moves the queue along
                          cout << " test length" << endl;
                          break;

                        case 'F':
                          cout << "It's a F" << endl;
                          financialAid.m_officeLine->add(Registrar.m_windows.get(c).m_customer->remove()); // removes from window then adds to next queue
                          Registrar.windowCustomer(m_secTime); // moves the queue along
                          break;

                        case 'R':
                          cout << "error, shouldn't be R" << endl;
                          break;

                        default:
                          cout << "invalid char" << endl;
                          break;
                    }
                    //send to second office
                    break;
                    case 2:
                    switch(Registrar.m_windows.get(c).getCustomer().getOfficeThree())
                    {
                        case 'C':
                          cout << "error, shouldn't be C" << endl;
                          break;

                        case 'F':
                          cout << "It's a F" << endl;
                          financialAid.m_officeLine->add(Cashier.m_windows.get(c).m_customer->remove()); // removes from window then adds to next queue
                          Cashier.windowCustomer(m_secTime); // moves the queue along
                          break;

                        case 'R':
                          cout << "It's a R" << endl;
                          Registrar.m_officeLine->add(Cashier.m_windows.get(c).m_customer->remove()); // removes from window then adds to next queue
                          Cashier.windowCustomer(m_secTime); // moves the queue along
                          break;

                        default:
                          cout << "invalid char" << endl;
                          break;
                    }
                    //send to third office
                    break;
                  }//switch statement to send to which office
                }//if statement if the departure time has been met
                }//checks if window is open
              }//loops for each window to check
            
            /*
            if (m_secTime == m_time * 60){ // the next hour that customers arrive, adds all of them to the queues

              for(int i = 0; i < m_nCustomers; ++i)
              { // creates each customer and adds them to their queue
                m_officeTimes = new int[3];
                m_officeTypes = new char[3];
                m_officeOrder = new char[3];

                for(int k = 0; k < 6; ++k) //reads each attribute and adds them to an array
                {
                  if(k <= 2)
                  {
                    inFile >> m_officeTimes[k];
                  }

                  else
                  {
                    inFile >> m_officeTypes[k - 3];
                    m_officeOrder[k - 3] = m_officeTypes[k - 3] ;
                  }
                }



                Customer c(m_officeTimes[0], m_officeTimes[1], m_officeTimes[2], m_officeOrder[0], m_officeOrder[1], m_officeOrder[2]); // creates customer object

                switch(c.getOfficeOne())//reads each character and finds which office to put them in first
                {
                    case 'C':
                      //cout << "It's a C" << endl;
                      Cashier.m_officeLine->add(c);
                      Cashier.windowCustomer();
                      break;

                    case 'F':
                      //cout << "It's a F" << endl;
                      financialAid.m_officeLine->add(c);
                      financialAid.windowCustomer();
                      break;

                    case 'R':
                      //cout << "It's a R" << endl;
                      Registrar.m_officeLine->add(c);
                      Registrar.windowCustomer();
                      break;

                    default:
                      cout << "invalid char" << endl;
                      break;
                } // first office bracket
                }//creates each customer object
              }//adds new set of customers bracket
              inFile >> m_time;
              inFile >> m_nCustomers;
              */
            }//time bracket 
            cout <<"offices visitied: " << financialAid.m_windows.get(0).m_customer->peek().getOfficesVisited() << endl;
            cout << "offices visitied: " << Registrar.m_windows.get(0).m_customer->peek().getOfficesVisited() << endl;
            satisfiedCustomers.addBack(financialAid.m_windows.get(0).m_customer->remove());
            satisfiedCustomers.addBack(Registrar.m_windows.get(0).m_customer->remove());
            cout << Cashier.totallyEmpty() << endl;
            cout << financialAid.totallyEmpty() << endl;
            cout << Registrar.totallyEmpty() << endl;
            cout << "satisfied customers: " << satisfiedCustomers.size() << endl;
          // std::cout << Cashier.m_officeLine->size() << std::endl;
          // std::cout << financialAid.m_officeLine->size() << std::endl;
          // std::cout << Registrar.m_officeLine->size() << std::endl;
          //cout << c.getOfficeOne() << " " << c.getOfficeTwo() << " " << c.getOfficeThree() << endl;
          }//initial assignment of m_time and m_nCustomers bracket
        //}//if file is open
      inFile.close();
      

    }//constructor bracket


