/// @file Window.cpp
/// @brief Allows for the creation of a Window object.
/// @author Tyler Edwards - tyedwards@chapman.edu

using namespace std;
#include "Window.h"

Window::Window()
{
  cout << "window created" << endl;
  m_idleTime = 0;
  m_longestIdleTime = 0;

  m_isOpen = true;
  m_overFive = false;
  m_customer = new ListQueue<Customer>;
}

Window::~Window(){
  //std::cout<<"window destructed" << std::endl;
}

int Window::print()
{
  return m_idleTime;
}

void Window::addCustomer(Customer c)
{
  c.setOfficesVisited();
  m_customer->add(c);
  //cout << c.getOfficesVisited() << endl;
  //cout << c.getOfficesVisited() << endl;
}

bool Window::windowOpen(){// change me
  if (m_customer->isEmpty()){
    //cout << "window empty" << endl;
    m_isOpen = true;
    return true;
  }
  else{
    //cout << "window occupied" << endl;
    m_isOpen = false;
    return false;
  }
}

Customer Window::getCustomer(){//change me
  return m_customer->peek();
}