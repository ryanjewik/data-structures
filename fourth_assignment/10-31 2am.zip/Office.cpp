/// @file Office.cpp
/// @brief Allows for the creation of a Office object.
/// @author Tyler Edwards - tyedwards@chapman.edu

using namespace std;

#include "Office.h"

Office::Office(){}

Office::~Office(){}

Office::Office(int n)
{
  m_nWindows = n;
  m_longestIdleTime = 0;
  m_windowsFive = 0;
  m_meanIdleTime = 0;

  m_officeLine = new ListQueue<Customer>;

  for(int i = 0; i < m_nWindows; ++i)
  {
    Window w;
    m_windows.addBack(w);
  }

  for(int i = 0; i < m_nWindows; ++i)
  {
    Window test = m_windows.get(i);
    //cout << test.print() << endl;
  }
}

void Office::windowCustomer(int secTime)//checks all windows and finds an open on, removes the first from the queue then passes into window
{
  //cout << "test before" << endl;
  for (int i = 0; i < m_nWindows; ++i){
    if (m_windows.get(i).windowOpen() == true){
        cout << "window: " << i << " is empty so we will add here." << endl;
        //cout << "office line size " << m_officeLine->size() << endl;
        if (!m_officeLine->isEmpty()){
        Customer tempC = m_officeLine->remove();
        //cout << "set" << endl;
        tempC.setDepartureTime(secTime);
        //tempC.setLeaveTime(secTime);
        //cout << "depart" << endl;
        m_windows.get(i).addCustomer(tempC);
        }
        //cout << "new test" << endl;
        break;
    }
  }
  
}

bool Office::totallyEmpty(){
  bool windowsEmptyVar = true;
  for(int i = 0; i < m_nWindows; ++i)
  {
    //cout <<"checking window: " << i << endl;
    if (m_windows.get(i).windowOpen() == false){
      windowsEmptyVar = false;
      //cout << "window: " << i << " is occupied." << endl;
      break;
    }else{
      //cout << "window: " << i << " is open." << endl;
    }
  }
  if (m_officeLine->isEmpty() == true && windowsEmptyVar == true){
    return true;
  }
  else{
    return false;
  }
}

bool Office::windowsEmpty(){
  for(int i = 0; i < m_nWindows; ++i)
  {
    //cout << "Check window: " << i << endl;
    if (m_windows.get(i).windowOpen() == false){
      return false;
      exit;
    }
  }
  return true;
}