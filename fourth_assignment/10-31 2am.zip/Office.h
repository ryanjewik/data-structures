/// @file Office.h
/// @brief Allows for the creation of a Office object. (header)
/// @author Tyler Edwards - tyedwards@chapman.edu

#ifndef OFFICE_H
#define OFFICE_H
#include <iostream>

#include "Window.h"
#include "DblList.h"
#include "ListQueue.h"
#include "ListNode.h"

class Office
{
  public:
    Office();
    virtual ~Office();
    Office(int w);

    int m_longestIdleTime;
    int m_windowsFive;
    int m_meanIdleTime;
    int m_meanWaitTime;

    ListQueue<Customer>* m_officeLine;
    DblList<Window> m_windows;

    void windowCustomer(int secTime);
    bool windowsEmpty();
    bool totallyEmpty();

  private:
    int m_nWindows;
};

#endif
