/// @file Customer.cpp
/// @brief Allows for the creation of a Customer object.
/// @author Tyler Edwards - tyedwards@chapman.edu

using namespace std;

#include "Customer.h"

Customer::Customer(){
  m_timeOne = -1;
  m_timeTwo = -1;
  m_timeThree = -1;
}

Customer::~Customer(){}

Customer::Customer(int t1, int t2, int t3, char o1, char o2, char o3)
{
  m_timeOne = t1;
  m_timeTwo = t2;
  m_timeThree = t3;

  m_officeOne = o1;
  m_officeTwo = o2;
  m_officeThree = o3;

  int m_cWait = 0;
  int m_fWait = 0;
  int m_rWait = 0;

  int lineArrival;
  this->m_officesVisited = 0;

  cout << m_timeOne << endl;
  cout << m_timeTwo << endl;
  cout << m_timeThree << endl;

  cout << m_officeOne << endl;
  cout << m_officeTwo << endl;
  cout << m_officeThree << endl;

  //m_customer = new DblList<Customer>;
}

int Customer::getTimeOne(){return m_timeOne;}
int Customer::getTimeTwo(){return m_timeTwo;}
int Customer::getTimeThree(){return m_timeThree;}

char Customer::getOfficeOne(){return m_officeOne;}
char Customer::getOfficeTwo(){return m_officeTwo;}
char Customer::getOfficeThree(){return m_officeThree;}

int Customer::getWaitC(){return m_cWait;}
int Customer::getWaitF(){return m_fWait;}
int Customer::getWaitR(){return m_rWait;}

void Customer::setWaitC(int t){m_cWait = t;}
void Customer::setWaitF(int t){m_fWait = t;}
void Customer::setWaitR(int t){m_rWait = t;}


void Customer::setDepartureTime(int currentTime){
  switch(m_officesVisited){
    case 0:
    m_departureTime =currentTime + m_timeOne;
    switch(m_officeOne){
      case 'C':
      m_cWait = currentTime - lineArrival;
      cout << "line wait time: " << m_cWait << endl;
      break;
      case 'F':
      m_fWait = currentTime - lineArrival;
      cout << "line wait time: " << m_fWait << endl;
      break;
      case 'R':
      m_rWait = currentTime - lineArrival;
      cout << "line wait time: " << m_rWait << endl;
      break;
    }
    break;
    case 1:
    m_departureTime =currentTime + m_timeTwo;
    switch(m_officeTwo){
      case 'C':
      m_cWait = currentTime - lineArrival;
      cout << "line wait time: " << m_cWait << endl;
      
      break;
      case 'F':
      m_fWait = currentTime - lineArrival;
      cout << "line wait time: " << m_fWait << endl;
      break;
      case 'R':
      m_rWait = currentTime - lineArrival;
      cout << "line wait time: " << m_rWait << endl;
      break;
    }
    break;
    case 2:
    m_departureTime =currentTime + m_timeThree;
    switch(m_officeThree){
      case 'C':
      m_cWait = currentTime - lineArrival;
      cout << "line wait time: " << m_cWait << endl;
      break;
      case 'F':
      m_fWait = currentTime - lineArrival;
      cout << "line wait time: " << m_fWait << endl;
      break;
      case 'R':
      m_rWait = currentTime - lineArrival;
      cout << "line wait time: " << m_rWait << endl;
      break;
    }
    break;
    default:
    m_departureTime = -1;
    break;
  }
  
  cout << "setting departure time... current time: " << currentTime << " therefore departure time: " << m_departureTime << endl;
}
int Customer::getDepartureTime(){
  return m_departureTime;
}
int Customer::getOfficesVisited(){
  return m_officesVisited;
}
void Customer::setOfficesVisited(){
  m_officesVisited +=1;
  //cout << "visited new office" << endl;
}

void Customer::setArrivalTime(int k){
  lineArrival = k;
  cout << "new arrival time: " << lineArrival << endl;
}
void Customer::setLeaveTime(int k){
  lineLeave = k;
}

int Customer::getArrivalTime(){
  return lineArrival;
}
int Customer::getLeaveTime(){
  return lineLeave;
}