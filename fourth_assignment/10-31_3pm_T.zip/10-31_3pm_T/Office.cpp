/// @file Office.cpp
/// @brief Allows for the creation of a Office object.
/// @author Tyler Edwards - tyedwards@chapman.edu

using namespace std;

#include "Office.h"

Office::Office(){}

Office::~Office(){}

Office::Office(int n)
{
  m_nWindows = n;
  m_longestIdleTime = 0;
  m_windowsFive = 0;
  m_meanIdleTime = 0;

  m_officeLine = new ListQueue<Customer>;

  for(int i = 0; i < m_nWindows; ++i)
  {
    Window w;
    m_windows.addBack(w);
    m_idleTimes.addBack(-1);
    m_isOverFive.addBack(false);
  }

  for(int i = 0; i < m_nWindows; ++i)
  {
    Window test = m_windows.get(i);
    //cout << test.print() << endl;
  }
}

void Office::windowCustomer(int secTime)//checks all windows and finds an open on, removes the first from the queue then passes into window
{
  for (int i = 0; i < m_nWindows; ++i){
    if (m_windows.get(i).windowOpen() == true){
        cout << "window: " << i << " is empty so we will add here." << endl;
        if (!m_officeLine->isEmpty()){ //makes sure line isn't empty
        Customer tempC = m_officeLine->remove();//removes customer from the queue
        //cout << tempC.getArrivalTime() << endl;
        //cout << tempC.getLeaveTime() << endl;
        tempC.setDepartureTime(secTime);//sets the time they will leave
        m_windows.get(i).addCustomer(tempC);//adds customer to the window
        }
        break;
    }
  }

}

bool Office::totallyEmpty(){//checks both the windows and the queue and sees if they're totally empty
  bool windowsEmptyVar = true;
  for(int i = 0; i < m_nWindows; ++i)
  {
    //cout <<"checking window: " << i << endl;
    if (m_windows.get(i).windowOpen() == false){
      windowsEmptyVar = false;
      //cout << "window: " << i << " is occupied." << endl;
      break;
    }else{
      //cout << "window: " << i << " is open." << endl;
    }
  }
  if (m_officeLine->isEmpty() == true && windowsEmptyVar == true){
    return true;
  }
  else{
    return false;
  }
}

bool Office::windowsEmpty(){//loops and checks if all of the windows are empty
  for(int i = 0; i < m_nWindows; ++i)
  {
    //cout << "Check window: " << i << endl;
    if (m_windows.get(i).windowOpen() == false){
      return false;
      exit;
    }
  }
  return true;
}

double Office::getMeanIdleTime()
{
  for(int i = 0; i < m_nWindows; ++i)
  {
    cout << m_idleTimes.get(i) << endl;
    m_meanIdleTime += (double) m_idleTimes.get(i);
  }

  cout << m_meanIdleTime << endl;
  return (m_meanIdleTime / (double) m_nWindows);
}

void Office::addIdleTime(int i)
{
  int temp = m_idleTimes.remove(i);
  temp++;
  m_idleTimes.add(i, temp);
}

void Office::removeIdleTime(int i)
{
  int temp = m_idleTimes.remove(i);
  temp--;
  m_idleTimes.add(i, temp);
}

void Office::overFive(int i)
{
  m_isOverFive.remove(i);
  m_isOverFive.add(i, true);
}

int Office::checkOverFive()
{
  int count = 0;
  for(int i = 0; i < m_nWindows; ++i)
  {
    if(m_isOverFive.get(i))
    {
      count++;
    }
  }

  return count;
}

int Office::longestIdleTime()
{
  int max = m_idleTimes.get(0);
  for(int i = 0; i < m_nWindows; ++i)
  {
    int check = m_idleTimes.get(i);
    if(check > max)
    {
      max = check;
    }
  }

  return max;
}
