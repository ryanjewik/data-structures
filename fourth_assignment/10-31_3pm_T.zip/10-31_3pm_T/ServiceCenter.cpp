/// @file ServiceCenter.h
/// @brief Allows for the creation of a Service Center object.
/// @author Tyler Edwards - tyedwards@chapman.edu

#include "ServiceCenter.h"

using namespace std;

ServiceCenter::ServiceCenter(){}

ServiceCenter::~ServiceCenter(){}

ServiceCenter::ServiceCenter(std::string file)
{
  m_file = file;
  ifstream inFile;
  inFile.open(m_file, ios::in);
  int stopTime;
  m_secTime = 0;
  inFile >> m_rWindow; // 2
  inFile >> m_cWindow; // 3
  inFile >> m_fWindow; // 1

  Office Registrar(m_rWindow);
  Office Cashier(m_cWindow);
  Office financialAid(m_fWindow);
  DblList<Office> Offices;
  Offices.addBack(Registrar);
  Offices.addBack(Cashier);
  Offices.addBack(financialAid);


    if (inFile.is_open()){
      //while(!inFile.eof()){
      inFile >> m_time;
      inFile >> m_nCustomers;
      //stopTime = m_time * 60;
        for(int i = 0; i < m_nCustomers; ++i) // populates the queues and reads the first hour
        {
          m_officeTimes = new int[3];
          m_officeTypes = new char[3];
          m_officeOrder = new char[3];

          for(int k = 0; k < 6; ++k)
          {
            if(k <= 2)
            {
              inFile >> m_officeTimes[k];
            }

            else
            {
              inFile >> m_officeTypes[k - 3];
              m_officeOrder[k - 3] = m_officeTypes[k - 3] ;
            }
          }


          Customer c(m_officeTimes[0], m_officeTimes[1], m_officeTimes[2], m_officeOrder[0], m_officeOrder[1], m_officeOrder[2]);

          switch(c.getOfficeOne())
          {
              case 'C':
                cout << "It's a C" << endl;
                c.setArrivalTime(m_secTime);
                Cashier.m_officeLine->add(c);
                Cashier.windowCustomer(0);
                break;

              case 'F':
                cout << "It's a F" << endl;
                c.setArrivalTime(m_secTime);
                financialAid.m_officeLine->add(c);
                financialAid.windowCustomer(0);
                break;

              case 'R':
                cout << "It's a R" << endl;
                c.setArrivalTime(m_secTime);
                Registrar.m_officeLine->add(c);
                Registrar.windowCustomer(0);
                break;

              default:
                cout << "invalid char" << endl;
                break;
          }
          }//initial set of students at opening
              cout << Cashier.totallyEmpty() << endl;
              cout << financialAid.totallyEmpty() << endl;
              cout << Registrar.totallyEmpty() << endl;
          cout << "--------------------------------- initial set of customers added" << endl;
          cout << endl;
          cout << endl;
          inFile >> m_time; // reads time again to know when the next wave of customers will arrive
          inFile >> m_nCustomers;
          stopTime = m_time * 60; // the time when it should check for the next wave of customers
          // cout << "time: " <<  m_time << endl;
          // cout << "customers: " << m_nCustomers << endl;
          //cout << "offices visited test: " << Registrar.m_windows.get(0).getCustomer().getOfficesVisited() << endl;
          //cout << Registrar.m_windows.get(0).getCustomer().getDepartureTime() << endl;
          // cout << Cashier.totallyEmpty() << endl;
          // cout << financialAid.totallyEmpty() << endl;
          // cout << Registrar.totallyEmpty() << endl;
          while((financialAid.totallyEmpty() != 1 || inFile.eof() != 1) || (Registrar.totallyEmpty() != 1 || Cashier.totallyEmpty() != 1)){//time only stops when it's the end of the file and the queues are empty
            m_secTime +=1; //time has started
            cout << "time: " << m_secTime << endl;
              for (int c = 0; c < Cashier.m_windows.size(); ++c){//Cashier check windows and see who is done
                if (Cashier.m_windows.get(c).windowOpen() != 1){
                if (Cashier.m_windows.get(c).getCustomer().getDepartureTime() == m_secTime){
                  Customer c1;
                  switch(Cashier.m_windows.get(c).getCustomer().getOfficesVisited()){
                    case 3:
                    //send to first office
                    satisfiedCustomers.addBack(Cashier.m_windows.get(c).m_customer->remove());
                    cout << "current time: " << m_secTime << " happy customer" << endl;
                    break;
                    case 1:
                    switch(Cashier.m_windows.get(c).getCustomer().getOfficeTwo())
                    {
                        case 'C':
                          cout << "error, shouldn't be C" << endl;
                          break;

                        case 'F':
                          cout << "It's a F" << endl;
                          c1 = Cashier.m_windows.get(c).m_customer->remove();
                          c1.setArrivalTime(m_secTime);
                          financialAid.m_officeLine->add(c1); // removes from window then adds to next queue
                          financialAid.windowCustomer(m_secTime); // moves the queue along

                          //financialAid.windowCustomer(m_secTime); // checks if that customer needs to be pushed into window
                          break;

                        case 'R':
                          cout << "It's a R" << endl;
                          c1 = Cashier.m_windows.get(c).m_customer->remove();
                          c1.setArrivalTime(m_secTime);
                          Registrar.m_officeLine->add(c1); // removes from window then adds to next queue
                          Registrar.windowCustomer(m_secTime); // moves the queue along
                          //Registrar.windowCustomer(m_secTime); // checks if that customer needs to be pushed into window
                          break;

                        default:
                          cout << "invalid char" << endl;
                          break;
                    }
                    //send to second office
                    break;
                    case 2:
                    switch(Cashier.m_windows.get(c).getCustomer().getOfficeThree())
                    {
                        case 'C':
                          cout << "error, shouldn't be C" << endl;
                          break;

                        case 'F':
                          cout << "It's a F" << endl;
                          c1 = Cashier.m_windows.get(c).m_customer->remove();
                          c1.setArrivalTime(m_secTime);
                          financialAid.m_officeLine->add(c1); // removes from window then adds to next queue
                          financialAid.windowCustomer(m_secTime); // moves the queue along
                          //financialAid.windowCustomer(m_secTime); // checks if that customer needs to be pushed into window
                          break;

                        case 'R':
                          cout << "It's a R" << endl;
                          c1 = Cashier.m_windows.get(c).m_customer->remove();
                          c1.setArrivalTime(m_secTime);
                          Registrar.m_officeLine->add(c1); // removes from window then adds to next queue
                          Registrar.windowCustomer(m_secTime); // moves the queue along
                          //Registrar.windowCustomer(m_secTime); // checks if that customer needs to be pushed into window
                          break;

                        default:
                          cout << "invalid char" << endl;
                          break;
                    }
                    //send to third office
                    break;
                  }//switch statement to send to which office
                  }//if statement if the departure time has been met
                }//if the window is occupied

                if (Cashier.m_windows.get(c).windowOpen() && !Cashier.m_officeLine->isEmpty()){//if there is an empty window and there are people in the line add them to a window
                  Cashier.windowCustomer(m_secTime);
                }
                else if(Cashier.m_windows.get(c).windowOpen() && Cashier.m_officeLine->isEmpty())
                {
                    cout << "else condition met" << endl;
                    Cashier.addIdleTime(c);
                    cout << Cashier.m_idleTimes.get(c) << endl;
                    if(Cashier.m_idleTimes.get(c) > 5)
                    {
                      Cashier.overFive(c);
                    }
                }
              }//loops for each window to check
              for (int c = 0; c < financialAid.m_windows.size(); ++c){//financial aid check windows and see who is done
                if (financialAid.m_windows.get(c).windowOpen() != 1){

                if (financialAid.m_windows.get(c).getCustomer().getDepartureTime() == m_secTime){
                  Customer c1;
                  switch(financialAid.m_windows.get(c).getCustomer().getOfficesVisited()){
                    case 3:
                    //send to first office
                    satisfiedCustomers.addBack(financialAid.m_windows.get(c).m_customer->remove());
                    cout << "current time: " << m_secTime << " happy customer" << endl;
                    break;
                    case 1:
                    switch(financialAid.m_windows.get(c).getCustomer().getOfficeTwo())
                    {
                        case 'C':
                          cout << "It's a C" << endl;
                          c1 = financialAid.m_windows.get(c).m_customer->remove();
                          c1.setArrivalTime(m_secTime);
                          Cashier.m_officeLine->add(c1); // removes from window then adds to next queue
                          Cashier.windowCustomer(m_secTime); // moves the queue along
                          //Cashier.windowCustomer(m_secTime); // checks if that customer needs to be pushed into window
                          break;

                        case 'F':
                          cout << "error, shouldn't be F" << endl;
                          break;

                        case 'R':
                          cout << "It's a R" << endl;
                          c1 = financialAid.m_windows.get(c).m_customer->remove();
                          c1.setArrivalTime(m_secTime);
                          Registrar.m_officeLine->add(c1); // removes from window then adds to next queue
                          Registrar.windowCustomer(m_secTime); // moves the queue along
                          //Registrar.windowCustomer(m_secTime); // checks if that customer needs to be pushed into window
                          break;

                        default:
                          cout << "invalid char" << endl;
                          break;
                    }
                    //send to second office
                    break;
                    case 2:
                    switch(financialAid.m_windows.get(c).getCustomer().getOfficeThree())
                    {
                        case 'C':
                          cout << "its a C" << endl;
                          c1 = financialAid.m_windows.get(c).m_customer->remove();
                          c1.setArrivalTime(m_secTime);
                          Cashier.m_officeLine->add(c1); // removes from window then adds to next queue
                          Cashier.windowCustomer(m_secTime); // moves the queue along
                          //Cashier.windowCustomer(m_secTime); // checks if that customer needs to be pushed into window
                          break;

                        case 'F':
                          cout << "error, shouldn't be F" << endl;
                          break;

                        case 'R':
                          cout << "It's a R" << endl;
                          c1 = financialAid.m_windows.get(c).m_customer->remove();
                          c1.setArrivalTime(m_secTime);
                          Registrar.m_officeLine->add(c1); // removes from window then adds to next queue
                          Registrar.windowCustomer(m_secTime); // moves the queue along
                         //Registrar.windowCustomer(m_secTime); // checks if that customer needs to be pushed into window
                          break;

                        default:
                          cout << "invalid char" << endl;
                          break;
                    }
                    //send to third office
                    break;
                  }//switch statement to send to which office
                }//if statement if the departure time has been met
                }//is window occupied

                if (financialAid.m_windows.get(c).windowOpen() && !financialAid.m_officeLine->isEmpty()){//if there is an empty window and there are people in the line add them to a window
                  financialAid.windowCustomer(m_secTime);
                }
                else if(financialAid.m_windows.get(c).windowOpen() && financialAid.m_officeLine->isEmpty())
                {
                    cout << "else condition met" << endl;
                    financialAid.addIdleTime(c);
                    cout << financialAid.m_idleTimes.get(c) << endl;
                    if(financialAid.m_idleTimes.get(c) > 5)
                    {
                        financialAid.overFive(c);
                    }
                }

              }//loops for each window to check

              for (int c = 0; c < Registrar.m_windows.size(); ++c){//registrar check windows and see who is done
                if (Registrar.m_windows.get(c).windowOpen() != 1){
                  if (Registrar.m_windows.get(c).getCustomer().getDepartureTime() == m_secTime){
                  Customer c1;
                  switch(Registrar.m_windows.get(c).getCustomer().getOfficesVisited()){
                    case 3:
                    //send to first office
                    satisfiedCustomers.addBack(Registrar.m_windows.get(c).m_customer->remove());
                    cout << "current time: " << m_secTime << " happy customer" << endl;
                    break;
                    case 1:

                    switch(Registrar.m_windows.get(c).getCustomer().getOfficeTwo())
                    {
                        case 'C':
                          cout << "It's a C" << endl;
                          c1 = Registrar.m_windows.get(c).m_customer->remove();
                          c1.setArrivalTime(m_secTime);
                          Cashier.m_officeLine->add(c1); // removes from window then adds to next queue

                          Cashier.windowCustomer(m_secTime); // moves the queue along
                          //Cashier.windowCustomer(m_secTime); // checks if that customer needs to be pushed into window
                          break;

                        case 'F':
                          cout << "It's a F" << endl;
                          c1 = Registrar.m_windows.get(c).m_customer->remove();
                          c1.setArrivalTime(m_secTime);
                          financialAid.m_officeLine->add(c1);
                          financialAid.windowCustomer(m_secTime); // moves the queue along
                          //financialAid.windowCustomer(m_secTime); // checks if that customer needs to be pushed into window
                          break;

                        case 'R':
                          cout << "error, shouldn't be R" << endl;
                          break;

                        default:
                          cout << "invalid char" << endl;
                          break;
                    }
                    //send to second office
                    break;
                    case 2:
                    switch(Registrar.m_windows.get(c).getCustomer().getOfficeThree())
                    {
                        case 'C':
                          cout << "It's a C" << endl;
                          c1 = Registrar.m_windows.get(c).m_customer->remove();
                          c1.setArrivalTime(m_secTime);
                          Cashier.m_officeLine->add(c1); // removes from window then adds to next queue
                          Cashier.windowCustomer(m_secTime); // moves the queue along
                          break;

                        case 'F':
                          cout << "It's a F" << endl;
                          c1 = Registrar.m_windows.get(c).m_customer->remove();
                          c1.setArrivalTime(m_secTime);
                          financialAid.m_officeLine->add(c1); // removes from window then adds to next queue
                          financialAid.windowCustomer(m_secTime); // moves the queue along
                          //financialAid.windowCustomer(m_secTime); // checks if that customer needs to be pushed into window
                          break;

                        case 'R':
                          cout << "Error, shouldn't be R" << endl;

                          //Registrar.windowCustomer(m_secTime); // checks if that customer needs to be pushed into window
                          break;

                        default:
                          cout << "invalid char" << endl;
                          break;
                    }
                    //send to third office
                    break;
                  }//switch statement to send to which office
                }//if statement if the departure time has been met
                }//checks if window is open

                if (Registrar.m_windows.get(c).windowOpen() && !Registrar.m_officeLine->isEmpty()){//if there is an empty window and there are people in the line add them to a window
                  Registrar.windowCustomer(m_secTime);
                }
                else if(Registrar.m_windows.get(c).windowOpen() && Registrar.m_officeLine->isEmpty())
                {
                    cout << "else condition met" << endl;
                    Registrar.addIdleTime(c);
                    cout << Registrar.m_idleTimes.get(c) << endl;
                    if(Registrar.m_idleTimes.get(c) > 5)
                    {
                      Registrar.overFive(c);
                    }
                }



              }//loops for each window to check


            if (m_secTime == stopTime){ // the next hour that customers arrive, adds all of them to the queues
              cout << "reached the next wave: " << stopTime << endl;
              for(int i = 0; i < m_nCustomers; ++i)
              { // creates each customer and adds them to their queue
                m_officeTimes = new int[3];
                m_officeTypes = new char[3];
                m_officeOrder = new char[3];

                for(int k = 0; k < 6; ++k) //reads each attribute and adds them to an array
                {
                  if(k <= 2)
                  {
                    inFile >> m_officeTimes[k];
                  }

                  else
                  {
                    inFile >> m_officeTypes[k - 3];
                    m_officeOrder[k - 3] = m_officeTypes[k - 3] ;
                  }
                }

                Customer c(m_officeTimes[0], m_officeTimes[1], m_officeTimes[2], m_officeOrder[0], m_officeOrder[1], m_officeOrder[2]); // creates customer object

                switch(c.getOfficeOne())//reads each character and finds which office to put them in first
                {
                    case 'C':
                      cout << "It's a C" << endl;
                      c.setArrivalTime(m_secTime);
                      cout << c.getOfficesVisited() << endl;
                      Cashier.m_officeLine->add(c);
                      Cashier.windowCustomer(m_secTime);
                      break;

                    case 'F':
                      cout << "It's a F" << endl;
                      c.setArrivalTime(m_secTime);
                      cout << c.getOfficesVisited() << endl;
                      financialAid.m_officeLine->add(c);
                      financialAid.windowCustomer(m_secTime);
                      break;

                    case 'R':
                      cout << "It's a R" << endl;
                      c.setArrivalTime(m_secTime);
                      cout << c.getOfficesVisited() << endl;
                      Registrar.m_officeLine->add(c);
                      Registrar.windowCustomer(m_secTime);
                      break;

                    default:
                      cout << "invalid char" << endl;
                      break;
                } // first office bracket
                }//creates each customer object
              inFile >> m_time;
              inFile >> m_nCustomers;
              stopTime = m_time * 60;
              }//adds new set of customers bracket


            }//time bracket
            //cout <<"offices visitied: " << financialAid.m_windows.get(0).m_customer->peek().getOfficesVisited() << endl;
            //cout << "offices visitied: " << Registrar.m_windows.get(0).m_customer->peek().getOfficesVisited() << endl;
            //satisfiedCustomers.addBack(financialAid.m_windows.get(0).m_customer->remove());
            //satisfiedCustomers.addBack(Registrar.m_windows.get(0).m_customer->remove());
            cout << "Cashier window: ";
            cout <<Cashier.m_windows.get(0).windowOpen() << endl;
            cout << "financial aid window: ";
            cout <<financialAid.m_windows.get(0).windowOpen() << endl;
            cout << "registrar window: ";
            cout <<Registrar.m_windows.get(0).windowOpen() << endl;
            cout << "Cashier line: ";
            cout << Cashier.m_officeLine->size() << endl;
            cout << "finnancial aid line: ";
            cout << financialAid.m_officeLine->size() << endl;
            cout << "registrar line: ";
            cout << Registrar.m_officeLine->size() << endl;


            cout << Cashier.totallyEmpty() << endl;
            cout << financialAid.totallyEmpty() << endl;
            cout << Registrar.totallyEmpty() << endl;
            cout << "satisfied customers: " << satisfiedCustomers.size() << endl;

            cout << m_time << endl;
            cout << m_nCustomers << endl;

            cout << "C idle time: " << Cashier.m_windows.get(0).getIdleTime() << endl;
            cout << "C idle time: " << Cashier.m_windows.get(1).getIdleTime() << endl;
            cout << "C idle time: " << Cashier.m_windows.get(2).getIdleTime() << endl;
            cout << "F idle time: " << financialAid.m_windows.get(0).getIdleTime() << endl;
            cout << "R idle time: " << Registrar.m_windows.get(0).getIdleTime() << endl;
            cout << "R idle time: " << Registrar.m_windows.get(1).getIdleTime() << endl;

            cout << Cashier.getMeanIdleTime() << endl << endl;
            cout << financialAid.getMeanIdleTime() << endl << endl;
            cout << Registrar.getMeanIdleTime() << endl << endl;

            cout << Cashier.longestIdleTime() << endl;
            cout << financialAid.longestIdleTime() << endl;
            cout << Registrar.longestIdleTime() << endl;

            int allOverFive = Cashier.checkOverFive() + financialAid.checkOverFive() + Registrar.checkOverFive();
            cout << allOverFive << endl;
          // std::cout << Cashier.m_officeLine->size() << std::endl;
          // std::cout << financialAid.m_officeLine->size() << std::endl;
          // std::cout << Registrar.m_officeLine->size() << std::endl;
          //cout << c.getOfficeOne() << " " << c.getOfficeTwo() << " " << c.getOfficeThree() << endl;
          }//initial assignment of m_time and m_nCustomers bracket
        //}//if file is open
      inFile.close();


    }//constructor bracket
