/// @file Office.cpp
/// @brief Allows for the creation of a Office object.
/// @author Tyler Edwards - tyedwards@chapman.edu

using namespace std;

#include "Office.h"

Office::Office(){}

Office::~Office(){}

Office::Office(int n)
{
  m_nWindows = n;
  m_longestIdleTime = 0;
  m_windowsFive = 0;
  m_meanIdleTime = 0;

  m_officeLine = new ListQueue<Customer>;

  for(int i = 0; i < m_nWindows; ++i)
  {
    Window w;
    m_windows.addBack(w);
  }

  for(int i = 0; i < m_nWindows; ++i)
  {
    Window test = m_windows.get(i);
    //cout << test.print() << endl;
  }
}

void Office::windowCustomer()
{
  Window w;
  w = m_windows.get(0);
  
  Customer test = m_officeLine->remove();
  
  Customer* testPointer = &test;
  
  w.addCustomer(testPointer);
  
}

bool Office::totallyEmpty(){
  bool windowsEmptyVar = true;
  for(int i = 0; i < m_nWindows; ++i)
  {
    if (m_windows.get(i).windowOpen() == false){
      windowsEmptyVar = false;
      
    }
  }
  if (m_officeLine->isEmpty() == true && windowsEmptyVar == true){
    return true;
  }
  else{
    return false;
  }
}

bool Office::windowsEmpty(){
  for(int i = 0; i < m_nWindows; ++i)
  {
    if (m_windows.get(i).windowOpen() == false){
      return false;
      exit;
    }
  }
  return true;
}