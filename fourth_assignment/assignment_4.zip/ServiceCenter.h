/// @file ServiceCenter.h
/// @brief Allows for the creation of a Service Center object. (header)
/// @author Tyler Edwards - tyedwards@chapman.edu

#ifndef SERVICECENTER_H
#define SERVICECENTER_H
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

#include "DblList.h"
#include "Customer.h"
#include "Office.h"

class ServiceCenter
{
  public:
    ServiceCenter();
    virtual ~ServiceCenter();
    ServiceCenter(std::string file);
    int m_secTime;
    void newWave();

  private:
    int m_rWindow;
    int m_cWindow;
    int m_fWindow;
    int m_time;
    int m_nCustomers;
    std::string m_file;

    int m_windowsFive;

    int* m_officeTimes;
    char* m_officeTypes;
    char* m_officeOrder;

    //Office* m_offices;
};

#endif
