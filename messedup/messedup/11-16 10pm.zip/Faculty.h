/// @file Faculty.h
/// @brief Allows for creation of Faculty objects implementing the person class.
/// @author Tyler Edwards - tyedwards@chapman.edu

#ifndef FACULTY_H
#define FACULTY_H

#include <string>
#include <iostream>
using namespace std;

#include "Person.h"
#include "DblList.h"

class Faculty : public Person
{
  private:
    string m_department;

  public:
    DblList<int> m_adviseesIds;
    Faculty(){}
    Faculty(int facultyId, string facultyName, string facultyLevel, string facultyDepartment) //constructor
    {
      this->m_id = facultyId;
      this->m_name = facultyName;
      this->m_level = facultyLevel;

      m_department = facultyDepartment;
    }

    void printInfo() //prints the faculty member's info
    {
      string nameIdLevel = this->getNameIdAndLevel();
      cout << nameIdLevel << endl;

      cout << "Department: " << this->m_department << endl;
      cout << "Advisee IDs" << endl;

      if(this->m_adviseesIds.isEmpty())
      {
        cout << "No advisees yet." << endl;
      }

      else
      {
        for(int i = 0; i < this->m_adviseesIds.size(); ++i)
        {
          cout << this->m_adviseesIds.size() << endl;
          cout << "Student " << i + 1 << ": " << this->m_adviseesIds.get(i) << endl;
        }
      }
    }

    void removeAdvisee(int id)
    {
      int pos = this->m_adviseesIds.search(id);
      this->m_adviseesIds.remove(pos);
    }

    void addAdvisee(int id) {this->m_adviseesIds.addBack(id);}
};

bool operator==(Faculty& lhs, Faculty& rhs) //overloads the == opterator
{return(lhs.getId() == rhs.getId());}

bool operator!=( Faculty& lhs,  Faculty& rhs) //overloads the != opterator
{return(lhs.getId() != rhs.getId());}

bool operator<( Faculty& lhs,  Faculty& rhs) //overloads the < opterator
{return(lhs.getId() < rhs.getId());}

bool operator>( Faculty& lhs,  Faculty& rhs) //overloads the > opterator
{return(lhs.getId() > rhs.getId());}

#endif
