/// @file Main.cpp
/// @brief Runs the database system.
/// @author Tyler Edwards - tyedwards@chapman.edu

#include <string>
#include <iostream>
using namespace std;

#include "Student.h"
#include "Faculty.h"
#include "ScapegoatST.h"

int main()
{
  int input;
  bool done = false;
  cout << "Hello! Welcome to the Student and Faculty Database." << endl;

  while(!done)
  {
    cout << endl << "Please select an option below: " << endl;

    cout << "1 - Print all students and their information" << endl;
    cout << "2 - Print all faculty and their information" << endl;
    cout << "3 - Find and display student information given the students id" << endl;
    cout << "4 - Find and display faculty information given the faculty id" << endl;
    cout << "5 - Add a new student" << endl;
    cout << "6 - Delete a student given the id" << endl;
    cout << "7 - Add a new faculty member" << endl;
    cout << "8 - Delete a faculty member given the id." << endl;
    cout << "9 - Change a student’s advisor given the student id and the new faculty id." << endl;
    cout << "10 - Remove an advisee from a faculty member given the ids." << endl;
    cout << "11 - Exit." << endl;

    cin >> input;
    cout << endl;

    int id;
    string name;
    string level;
    string major;
    double gpa;
    int advisor;
    string department;

    int s_id;
    int f_id;

    char confirm;

    ScapegoatST<Student> students;
    ScapegoatST<Faculty> faculty;

    switch(input)
    {
      case 1: //print students
      {
        //cout <<students.getRoot()<<endl;
        students.ascArray(students.getRoot());

        break;
      }

      case 2: //print faculty
      {
        faculty.ascArray(faculty.getRoot());

        break;
      }

      case 3: //print specific student
      {
        cout << "Please enter ID of the student: " << endl;
        cin >> id;

        bool sinSystem = students.contains(id);
        while(sinSystem == false)
        {
          cout << "There is no student with that ID. Please enter a new ID or -1 to quit: " << endl;
          cin >> id;
          sinSystem = students.contains(id);

          if(id == -1) {break;}
        }

          cout << "Found them!" << endl;
          Student sPrint = students.getPerson(id);
          sPrint.printInfo();

        break;
      }

      case 4: //print specific faculty
      {
        cout << "Please enter ID of the faculty member: " << endl;
        cin >> id;

        bool finSystem = faculty.contains(id);
        while(finSystem == false)
        {
          cout << "There is no student with that ID. Please enter a new ID or -1 to quit: " << endl;
          cin >> id;
          finSystem = students.contains(id);

          if(id == -1) {break;}
        }

          cout << "Found them!" << endl;
          Faculty fPrint = faculty.getPerson(id);
          fPrint.printInfo();

        break;
      }

      case 5: //add student
      {
        cout << "Please enter ID: ";
        cin >> id;

        cout << "Please enter name: ";
        cin >> name;

        cout << "Please enter level: ";
        cin >> level;

        cout << "Please enter major: ";
        cin >> major;

        cout << "Please enter GPA: ";
        cin >> gpa;

        cout << "Please enter Advisor ID: ";
        cin >> advisor;
        cout << endl;

        Student sAdd(id, name, level, major, gpa, advisor);
        sAdd.printInfo();
        students.insert(sAdd);
        break;
      }

      case 6: //remove student
      {
        cout << "Please enter ID of student to delete: " << endl;
        cin >> id;

        while(!(students.contains(id)))
        {
          cout << "There is no student with that ID. Please enter a new ID or -1 to quit: " << endl;
          cin >> id;

          if(id == -1) {break;}
        }

          cout << "Found them!" << endl;

        students.getPerson(id).printInfo();

        cout << "Delete this user? y/n" << endl;
        cin >> confirm;

        while(confirm != 'y' || confirm != 'n')
        {
          cout << "Please enter a valid letter: " << endl;
          cin >> confirm;
        }

        if(confirm == 'y')
        {
          int oldAdv = students.getPerson(id).getAdvisor();
          faculty.getPerson(oldAdv).removeAdvisee(id);

          students.removeInt(id);
        }
        else {cout << "This student has not been deleted." << endl;}
        break;
      
      }

      case 7: //add faculty
      {
        cout << "Please enter ID: ";
        cin >> id;

        cout << "Please enter name: ";
        cin >> name;

        cout << "Please enter level: ";
        cin >> level;

        cout << "Please enter department: ";
        cin >> department;
        cout << endl;

        Faculty fAdd(id, name, level, department);
        fAdd.printInfo();
        faculty.insert(fAdd);
        break;
      }

      case 8: //remove faculty
      {/*
        cout << "Please enter ID of a faculty member to delete: " << endl;
        cin >> id;

        if(!(faculty.contains(id)))
        {
          cout << "There is no faculty member with that ID. Please enter a new ID: " << endl;
          cin >> id;
        }

        else
        {
          cout << "Found them!" << endl;
        }

        faculty.getPerson(id).printInfo();

        cout << "Delete this user? y/n" << endl;
        cin >> confirm;

        if(confirm == 'y')
        {
          [NEED CODE HERE] //recording the ids of the advisees then establishing a new faculty for them

          faculty.removeInt(id);
        }

        else if(confirm == 'n'){cout << "This faculty has not been deleted." << endl;}
        else
        {
          cout << "Please enter a valid letter" << endl;
          cin >> confirm;
        }
        */
        break;
        
      }

      case 9: //changing student advisor
      {
        cout << "Please enter ID of the student that you would like to change the advisor of: " << endl;
        cin >> s_id;

        while(!(students.contains(s_id)))
        {
          cout << "There is no student with that ID. Please enter a new ID or -1 to exit: " << endl;
          cin >> s_id;

          if(s_id == -1) {break;}
        }

          cout << "Found them!" << endl;

        students.getPerson(s_id).printInfo();

        cout << "Please enter ID of the new faculty adivsor of this student: " << endl;
        cin >> f_id;

        while(!(faculty.contains(f_id)))
        {
          cout << "There is no faculty member with that ID. Please enter a new ID or -1 to exit: " << endl;
          cin >> f_id;

          if(f_id == -1) {break;}
        }

          cout << "Found them!" << endl;

        faculty.getPerson(f_id).printInfo();

        cout << "Is this the correct student and faculty advisor? y/n" << endl;
        cin >> confirm;

        while(confirm != 'y' || confirm != 'n')
        {
          cout << "Please enter a valid letter: " << endl;
          cin >> confirm;
        }

        if(confirm == 'y')
        {
          int oldAdv = students.getPerson(s_id).getAdvisor();
          students.getPerson(s_id).swapAdvisor(f_id);
          faculty.getPerson(f_id).addAdvisee(s_id);
          faculty.getPerson(oldAdv).removeAdvisee(s_id);
        }
        else {cout << "The faculty advisor has not been changed." << endl;}

        break;
      }

      case 10: //removing advisee
      {/*
        cout << "Please enter ID of the faculty member you'd like to remove the advisee from: " << endl;
        cin >> f_id;

        if(!(faculty.contains(f_id)))
        {
          cout << "There is no faculty member with that ID. Please enter a new ID: " << endl;
          cin >> id;
        }

        else
        {
          cout << "Found them!" << endl;
        }

        faculty.getPerson(f_id).printInfo();

        cout << "Please enter ID of the advisee you would like to remove: " << endl;
        cin >> s_id;

        if(!(students.contains(s_id)))
        {
          cout << "There is no student with that ID. Please enter a new ID: " << endl;
          cin >> s_id;
        }

        else
        {
          cout << "Found them!" << endl;
        }

        students.getPerson(s_id).printInfo();

        cout << "Is this the correct student and faculty advisor? y/n" << endl;
        cin >> confirm;

        if(confirm == 'y')
        {
          faculty.getPerson(f_id).removeAdvisee(s_id);

          int newId;
          if(faculty.get(0).getId() != f_id)
          {newId = faculty.get(0).getId();}
          
          else
          {newId = faculty.get(1).getId();}

          students.getPerson(s_id).swapAdvisor(newId);
        }
        else if(confirm == 'n'){cout << "The advisee has not been removed." << endl;}
        else
        {
          cout << "Please enter a valid letter" << endl;
          cin >> confirm;
        }
        */
        break;
      }

      case 11: //exit
      {
        cout << "Goodbye! :)" << endl;
        done = true;
        break;
      }

      default:
      {
        cout << "That's not a valid number. Please type a different input:" << endl;
        cin >> input;
        break;
      }
    } // switch statement
  } // while loop
}
