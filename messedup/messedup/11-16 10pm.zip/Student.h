/// @file Student.h
/// @brief Allows for creation of Student objects implementing the person class.
/// @author Tyler Edwards - tyedwards@chapman.edu

#ifndef STUDENT_H
#define STUDENT_H

#include <string>
#include <iostream>
using namespace std;

#include "Person.h"
#include "DblList.h"

class Student : public Person
{
  private:
    string m_major;
    double m_gpa;
    int m_advisorId;

  public:
  Student(){}
    Student(int studentId, string studentName, string studentLevel, string studentMajor, double studentGpa, int studentAdvisorId)
    { //constructor
      this->m_id = studentId;
      this->m_name = studentName;
      this->m_level = studentLevel;

      m_major = studentMajor;
      m_gpa = studentGpa;
      m_advisorId = studentAdvisorId;
    }

    void printInfo() //prints the student's info
    {
      string nameIdLevel = this->getNameIdAndLevel();
      cout << nameIdLevel << endl;

      cout << "Major: " << this->m_major << endl;
      cout << "GPA: " << this->m_gpa << endl;
      cout << "Advisor ID: " << this->m_advisorId << endl;
    }

    int getAdvisor() {return m_advisorId;}

    void swapAdvisor(int newId) {m_advisorId = newId;}
};

bool operator==( Student& lhs,  Student& rhs) //overloads the == opterator
{return(lhs.getId() == rhs.getId());}

bool operator!=( Student& lhs,  Student& rhs) //overloads the != opterator
{return(lhs.getId() != rhs.getId());}

bool operator<( Student& lhs,  Student& rhs) //overloads the < opterator
{return(lhs.getId() < rhs.getId());}

bool operator>( Student& lhs,  Student& rhs) //overloads the > opterator
{return(lhs.getId() > rhs.getId());}
#endif
