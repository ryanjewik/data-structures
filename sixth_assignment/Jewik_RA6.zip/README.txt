1)
a.Ryan Jewik
b.2404275
c.jewik@chapman.edu
d.CPSC350-01
e.Programming Assignment 6: Spanning the Gamut
2)
a. main.cpp
b. DblList.h
c. ListNode.h
d. PQueue.h
e. WGraph.cpp
f. WGraph.h
3) n/a 
4) n/a 
5) g++ *.cpp -o run
./run sampleInput.txt