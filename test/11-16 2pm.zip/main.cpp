#include <iostream>
#include "ScapegoatST.h"
//#include "TreeNode.h"
//#include "BST.h"
using namespace std;

int main(){
    ScapegoatST<int> scapeTree;
     scapeTree.insert(10);
    scapeTree.insert(4);
    scapeTree.insert(20);
    scapeTree.insert(30);
    scapeTree.insert(7);
    scapeTree.insert(14);
    scapeTree.insert(31);
    scapeTree.insert(40);
    scapeTree.insert(55);
    scapeTree.insert(50);
    scapeTree.insert(35);
    //scapeTree.printTreePostOrder();
    //cout << scapeTree.getTotalSize() << endl;

    cout << "--------------------------------------------"<<endl;

    scapeTree.testPrint();
    //scapeTree.printTreePostOrder();
   // scapeTree.remove(20);
    //cout << scapeTree.getSizeAtNode()
    //cout << scapeTree.nodeTreeSize(scapeTree.getRoot(),scapeTree.getRoot()) << endl;
    //scapeTree.printTreePostOrder();
    

    return 0;
}