#include "SpeakerView.h"
//#include "MonoStack.h"
//#include "SpeakerView.cpp"
#include <iostream>
#include <string>
using namespace std;


int main(int argc, char** argv){
    SpeakerView s(argv[1]);

    return 0;
}
